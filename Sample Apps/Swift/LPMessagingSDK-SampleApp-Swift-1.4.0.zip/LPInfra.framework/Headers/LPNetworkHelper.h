//
//  LPNetworkHelper.h
//  
//
//  Created by Nir Lachman on 21/08/2016.
//
//

#import <Foundation/Foundation.h>

@interface LPNetworkHelper : NSObject
+ (NSString *)getExternalIPAddress;
@end
