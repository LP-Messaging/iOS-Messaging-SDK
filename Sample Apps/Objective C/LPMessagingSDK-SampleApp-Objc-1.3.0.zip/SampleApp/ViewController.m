//
//  ViewController.m
//  SampleApp
//
//  Created by Nimrod Shai on 2/11/16.
//  Copyright © 2016 LivePerson. All rights reserved.
//

#import "ViewController.h"
#import <LPMessagingSDK/LPMessagingSDK.h>
#import <LPInfra/LPInfra.h>
#import <LPAMS/LPAMS.h>


#define WINDOW_SWITCH @"windowSwitch"
#define AUTHENTIACTION_SWITCH @"authenticationSwitch"


@interface ViewController ()<LPMessagingSDKdelegate>

@property (nonatomic, strong) id <ConversationParamProtocol> conversationQuery;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    BOOL windowSwitch = [[NSUserDefaults standardUserDefaults] boolForKey:WINDOW_SWITCH];
    self.windowSwitch.on = windowSwitch;
    
    BOOL authenticationSwitch = [[NSUserDefaults standardUserDefaults] boolForKey:AUTHENTIACTION_SWITCH];
    self.authenticationSwitch.on = authenticationSwitch;
    
    NSError *error = nil;
    [[LPMessagingSDK instance] initialize:self.accountTextField.text error:&error];
    if (error) {
        NSLog(@"LPMessagingSDK Initialize Error: %@",error);
        return;
    }
    
    [LPMessagingSDK instance].delegate = self;
    [self setSDKConfigurations];
    [[LPMessagingSDK instance] subscribeLogEvents:LogLevelINFO logEvent:^(LPLog *log) {
        NSLog(@"LPMessaging Log: %@", log.text);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
     This method sets the SDK configurations.
     For example:
     Change background color of remote user (such as Agent)
     Change background color of user (such as Consumer)
 */
- (void)setSDKConfigurations {
    LPConfig *configurations = [LPConfig defaultConfiguration];
    configurations.remoteUserBubbleBackgroundColor = [UIColor greenColor];
    configurations.userBubbleBackgroundColor = [UIColor lightGrayColor];
}

/**
 This method sets the user details such as first name, last name, profile image and phone number.
 */
- (void)setUserDetails {
    LPUser *user = [[LPUser alloc] initWithFirstName:self.firstNameTextField.text lastName:self.lastNametextField.text nickName:@"my nickname" uid:nil profileImageURL:@"http://www.mrbreakfast.com/ucp/342_6053_ucp.jpg" phoneNumber:@"000-0000000" employeeID:@"1111-11111"];
    [[LPMessagingSDK instance] setUserProfile:user brandID:self.accountTextField.text];
}

/**
 This method lets you enter a UIBarButton to the navigation bar (in window mode).
 When the button is pressed it will call the following delegate method: LPMessagingSDKCustomButtonTapped
 */
- (void)setCustomButton {
    UIImage *customButtonImage = [UIImage imageNamed:@"phone_icon"];
    [[LPMessagingSDK instance] setCustomButton:customButtonImage];
}

#pragma mark - IBActions

/**
 This method shows the conversation screen. It considers different modes:

 Window Mode:
 - Window           - Shows the conversation screen in a new window created by the SDK. Navigation bar is included.
 - View controller  - Shows the conversation screen in a view controller of your choice.
 
 Authentication Mode:
 - Authenticated    - Conversation history is saved and shown.
 - Unauthenticated  - Conversation starts clean every time.
 
 */
- (IBAction)showConversation:(id)sender {
    
    NSString *account = self.accountTextField.text;
    self.conversationQuery = [[LPMessagingSDK instance] getConversationBrandQuery:account];
    
    if (self.windowSwitch.on) {
        if (self.authenticationSwitch.on) {
            [[LPMessagingSDK instance] showConversation:self.conversationQuery authenticationCode:account containerViewController:nil];
        } else {
            [[LPMessagingSDK instance] showConversation:self.conversationQuery authenticationCode:nil containerViewController:nil];
        }
    } else {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        self.conversationViewController = [storyBoard instantiateViewControllerWithIdentifier:@"ConversationViewController"];
        self.conversationViewController.account = account;
        self.conversationViewController.conversationQuery = self.conversationQuery;

        if (self.authenticationSwitch.on) {
            [[LPMessagingSDK instance] showConversation:self.conversationQuery authenticationCode:account containerViewController:self.conversationViewController];
        } else {
            [[LPMessagingSDK instance] showConversation:self.conversationQuery authenticationCode:nil containerViewController:self.conversationViewController];
        }
        [[self navigationController] pushViewController:self.conversationViewController animated:true];
    }
    
    [self setUserDetails];
    [self setCustomButton];
    [[self view] endEditing:YES];
}

- (IBAction)windowSwitchChanged:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.on forKey:WINDOW_SWITCH];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (IBAction)authenticationSwitchChanged:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.on forKey:AUTHENTIACTION_SWITCH];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


#pragma mark - LPMessagingSDKDelegate

/**
 This delegate method is required.
 It is called when authentication process fails
 */
- (void)LPMessagingSDKAuthenticationFailed:(NSError *)error {
    NSLog(@"Error: %@",error);
}

/**
 This delegate method is required.
 It is called when the SDK version you're using is obselete and needs an update.
 */
- (void)LPMessagingSDKObseleteVersion:(NSError *)error {
    NSLog(@"Error: %@",error);
}

/**
 This delegate method is optional.
 It is called each time the SDK receives info about the agent on the other side.

 Example:
 You can use this data to show the agent details on your navigation bar (in view controller mode)
 */
-(void)LPMessagingSDKAgentDetails:(LPUser *)agent {
    if (agent != nil) {
        self.title = [NSString stringWithFormat:@"%@ %@",agent.firstName, agent.lastName];
    } else {
        self.title = @"";
    }
}

/**
 This delegate method is optional.
 It is called each time the SDK menu is opened/closed.
 */
- (void)LPMessagingSDKActionsMenuToggled:(BOOL)toggled {
    
}

/**
 This delegate method is optional.
 It is called each time the agent typing state changes.
 */
- (void)LPMessagingSDKAgentIsTypingStateChanged:(BOOL)isTyping {
    
}

/**
 This delegate method is optional.
 It is called after the customer satisfaction page is submitted with a score.
 */
- (void)LPMessagingSDKCSATScoreSubmissionDidFinish:(NSString *)accountID rating:(NSInteger)rating {
    
}

/**
 This delegate method is optional.
 If you set a custom button, this method will be called when the custom button is clicked.
 */
- (void)LPMessagingSDKCustomButtonTapped {
    
}

/**
 This delegate method is optional.
 It is called whenever an event log is received.
 */
- (void)LPMessagingSDKDidReceiveEventLog:(NSString *)eventLog {
    
}

/**
 This delegate method is optional.
 It is called when the SDK has connections issues.
 */
- (void)LPMessagingSDKHasConnectionError:(NSString *)error {
    
}

/**
 This delegate method is required.
 It is called when the token which used for authentication is expired
 */
-(void)LPMessagingSDKTokenExpired:(NSString *)brandID {
    
}

/**
 This delegate method is required.
 It lets you know if there is an error with the SDK and what the error is
 */
-(void)LPMessagingSDKError:(NSError *)error {
    
}

@end
