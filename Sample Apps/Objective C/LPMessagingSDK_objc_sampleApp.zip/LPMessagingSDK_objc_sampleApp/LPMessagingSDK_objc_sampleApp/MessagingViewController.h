//
//  MessagingViewController.h
//  LPMessagingSDK_objc_sampleApp
//
//  Created by Nimrod Shai on 1/12/16.
//  Copyright © 2016 LivePerson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessagingViewController : UIViewController

@end
