//
//  MessagingViewController.m
//  LPMessagingSDK_objc_sampleApp
//
//  Created by Nimrod Shai on 1/12/16.
//  Copyright © 2016 LivePerson. All rights reserved.
//

#import "MessagingViewController.h"
#import <LPMessagingSDK/LPMessagingSDK.h>

@interface MessagingViewController () <LPMessagingSDKdelegate>

@end

@implementation MessagingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[LPMessagingSDK instance] setDelegate:self];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Required delegates

- (void)LPMessagingSDKObseleteVersion:(NSError *)error {
    
}

- (void)LPMessagingSDKAuthenticationFailed:(NSError *)error {
    
}

- (void)LPMessagingSDKDataEncryptionFailed:(NSError *)error {
    
}

#pragma mark - Optional delegates

- (void)LPMessagingSDKCustomButtonTapped {
    
}

- (void)LPMessagingSDKAgentDetails:(LPUser *)agent {
    self.navigationController.navigationBar.topItem.title = [NSString stringWithFormat:@"%@ %@",agent.firstName, agent.lastName];
}

- (void)LPMessagingSDKActionsMenuToggled:(BOOL)toggled {
    
}

- (void)LPMessagingSDKHasConnectionError:(NSString *)error {
    
}

- (void)LPMessagingSDKDidReceiveEventLog:(NSString *)eventLog {
    
}

@end
