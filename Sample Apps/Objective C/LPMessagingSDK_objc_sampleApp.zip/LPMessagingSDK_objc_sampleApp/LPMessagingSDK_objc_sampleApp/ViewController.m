//
//  ViewController.m
//  LPMessagingSDK_objc_sampleApp
//
//  Created by Nimrod Shai on 1/12/16.
//  Copyright © 2016 LivePerson. All rights reserved.
//

#import "ViewController.h"
#import <LPMessagingSDK/LPMessagingSDK.h>
#import "MessagingViewController.h"

@interface ViewController () 

@end

@implementation ViewController 

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[LPMessagingSDK instance] initialize:nil];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController.navigationItem setTitle:@"Home"];
}

- (IBAction)startButtonPressed:(id)sender {
    if ([self.accountNumberTextField.text isEqualToString:@""]) {
        self.accountNumberTextField.backgroundColor = [UIColor redColor];
    } else {
        
        MessagingViewController *messagingVC = [[MessagingViewController alloc] initWithNibName:@"MessagingViewController" bundle:nil];
        [self.navigationController pushViewController:messagingVC animated:YES];
        [[LPMessagingSDK instance] showConversation:self.accountNumberTextField.text authenticationCode:nil containerViewController:messagingVC];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
